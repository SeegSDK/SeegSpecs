#import <Foundation/Foundation.h>
#import <SeegSDK/ZSMarketProviding.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZSApplePaySDK : NSObject<ZSMarketProviding>

@end

NS_ASSUME_NONNULL_END
