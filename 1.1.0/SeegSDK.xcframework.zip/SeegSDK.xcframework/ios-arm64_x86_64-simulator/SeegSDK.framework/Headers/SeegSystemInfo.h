#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 系统信息数据模型
@interface SeegSystemInfo : NSObject

/// 品牌
@property (nonatomic, copy, nonnull) NSString *brand;
/// 型号
@property (nonatomic, copy, nonnull) NSString *model;
/// 屏幕宽度
@property (nonatomic, assign) CGFloat screenWidth;
/// 屏幕高度
@property (nonatomic, assign) CGFloat screenHeight;
/// 窗口宽度
@property (nonatomic, assign) CGFloat windowWidth;
/// 窗口高度
@property (nonatomic, assign) CGFloat windowHeight;
/// 状态栏高度
@property (nonatomic, assign) CGFloat statusBarHeight;
/// 语言
@property (nonatomic, copy, nonnull) NSString *language;
/// appName
@property (nonatomic, copy, nonnull) NSString *appName;
/// packageName
@property (nonatomic, copy, nonnull) NSString *packageName;
/// 版本号
@property (nonatomic, copy, nonnull) NSString *version;
/// 构建版本号
@property (nonatomic, copy, nonnull) NSString *versionCode;
/// 系统版本
@property (nonatomic, copy, nonnull) NSString *system;
/// 平台
@property (nonatomic, copy, nonnull) NSString *platform;
/// SDK版本
@property (nonatomic, copy, nonnull) NSString *SDKVersion;
/// 安全区
@property (nonatomic, copy, nonnull) NSDictionary *safeArea;

/// 转为 JSON 字符串
- (nullable NSString *)toJSONString;

@end

NS_ASSUME_NONNULL_END
