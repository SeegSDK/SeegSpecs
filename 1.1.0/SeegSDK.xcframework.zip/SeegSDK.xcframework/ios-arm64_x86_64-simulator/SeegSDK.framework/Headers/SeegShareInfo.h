#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// SDK分享信息
@interface SeegShareInfo : NSObject

/// 标题
@property (nonatomic, copy, nonnull) NSString *title;
/// 内容
@property (nonatomic, copy, nonnull) NSString *content;
/// 链接
@property (nonatomic, copy, nonnull) NSString *url;
/// 图片URL
@property (nonatomic, copy, nonnull) NSString *imgUrl;
/// 图片
@property (nonatomic, copy, nonnull) UIImage *img;
/// 视频文件
@property (nonatomic, copy, nonnull) NSString *videoFile;

@end

NS_ASSUME_NONNULL_END
