#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegPurchaseEvent : NSObject

/// 订单ID
@property (nonatomic, copy, nonnull) NSString *orderId;
/// 订单类型
@property (nonatomic, copy, nonnull) NSString *orderType;
/// 商品价格
@property (nonatomic, assign) double price;
/// 货币
@property (nonatomic, copy, nonnull) NSString *currency;
/// 商品ID
@property (nonatomic, copy, nonnull) NSString *productId;
/// 购买凭证
@property (nonatomic, copy, nonnull) NSString *token;
/// 是否首次购买
@property (nonatomic, assign) bool first;

+ (instancetype _Nullable )fromJsonString:(NSString *_Nonnull)jsonString;

@end

NS_ASSUME_NONNULL_END
