#import <Foundation/Foundation.h>

//! Project version number for ZSFirebase.
FOUNDATION_EXPORT double ZSFirebaseVersionNumber;

//! Project version string for ZSFirebase.
FOUNDATION_EXPORT const unsigned char ZSFirebaseVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZSFirebase/PublicHeader.h>
