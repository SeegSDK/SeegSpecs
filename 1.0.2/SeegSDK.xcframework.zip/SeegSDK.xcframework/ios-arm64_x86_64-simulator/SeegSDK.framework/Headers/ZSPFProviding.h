#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <SeegSDK/SeegShareInfo.h>

@protocol ZSPFProviding

///// 分享
//+ (void)share:(SeegShareInfo *)data;
///// 处理 URL 跳转回 app（Facebook 登录、分享回调）
//+ (BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options;

@end
