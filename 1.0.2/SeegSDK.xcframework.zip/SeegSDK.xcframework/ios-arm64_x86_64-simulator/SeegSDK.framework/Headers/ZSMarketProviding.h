#import <Foundation/Foundation.h>
#import <SeegSDK/ZSInitProviding.h>
#import <SeegSDK/SeegPlayInfo.h>

@protocol ZSMarketProviding<ZSInitProviding>

///// 发起支付
//+ (void)pay:(SeegPlayInfo *)data;
///// 消耗(完成)订单
//+ (void)consumeOrder:(SeegPlayInfo *)data;

@end
