#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// SDK支付信息
@interface SeegPlayInfo : NSObject

/// 商品ID
@property (nonatomic, copy, nonnull) NSString *productId;
/// 订单ID
@property (nonatomic, copy, nonnull) NSString *orderId;
/// 用户ID
@property (nonatomic, copy, nonnull) NSString *userId;

@end

NS_ASSUME_NONNULL_END
