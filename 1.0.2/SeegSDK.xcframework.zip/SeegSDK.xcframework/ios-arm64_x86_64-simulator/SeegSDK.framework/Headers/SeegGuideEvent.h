#import <Foundation/Foundation.h>

/// SDK广告收益信息
@interface SeegGuideEvent : NSObject

@property (nonatomic, assign) int ID;

@property (nonatomic, assign) BOOL startOrEnd;

+ (instancetype)fromJsonString:(NSString *)jsonString;

@end

