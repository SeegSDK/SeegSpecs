#import <Foundation/Foundation.h>


@interface SeegConsts : NSObject

+ (NSString *)AD_SOURCE_APPLOVIN;
+ (NSString *)AD_CURRENCY_USD;
+ (NSString *)AD_PLACEMENT_SPLASH;
+ (NSString *)AD_PLACEMENT_BANNER;
+ (NSString *)AD_PLACEMENT_INTERSTITIAL;
+ (NSString *)AD_PLACEMENT_REWARDED;
+ (NSString *)AD_PLACEMENT_CUSTOM;
+ (NSString *)USER_INFO_TYPE_SET_ONCE;
+ (NSString *)USER_INFO_TYPE_SET;
+ (NSString *)EVENT_REGISTER;
+ (NSString *)EVENT_LOGIN;
+ (NSString *)EVENT_LOAD_COMPLETE;
+ (NSString *)EVENT_GUIDE_START;
+ (NSString *)EVENT_GUIDE_END;
+ (NSString *)EVENT_AD_START;
+ (NSString *)EVENT_AD_LOAD;
+ (NSString *)EVENT_AD_LOAD_FAIL;
+ (NSString *)EVENT_AD_SHOW;
+ (NSString *)EVENT_AD_SHOW_FAIL;
+ (NSString *)EVENT_AD_CANCEL;
+ (NSString *)EVENT_AD_END;
+ (NSString *)EVENT_AD_REVENUE;
+ (NSString *)EVENT_LEVEL_START;
+ (NSString *)EVENT_LEVEL_LOSE;
+ (NSString *)EVENT_LEVEL_PASS;
+ (NSString *)EVENT_LEVEL_PROP_USE;
+ (NSString *)EVENT_CUSTOM;
+ (int)AD_TYPE_SPLASH;
+ (int)AD_TYPE_BANNER;
+ (int)AD_TYPE_INTERSTITIAL;
+ (int)AD_TYPE_REWARDED_VIDEO;
+ (int)AD_TYPE_CUSTOM;

@end

@interface SeegConfig: NSObject

@property(nonatomic, copy, readonly) NSString *channel;
@property(nonatomic, assign, readonly) BOOL debug;
// =0 关闭信息打印 =1 打印错误信息 =2 打印全部信息
@property(nonatomic, assign, readonly) int loggerLevel;

- (instancetype)initWith:(NSString *)channel :(BOOL) debug :(int) loggerLevel;

@end
