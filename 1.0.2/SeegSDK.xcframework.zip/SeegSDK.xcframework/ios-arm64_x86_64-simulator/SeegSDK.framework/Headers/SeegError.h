#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * 广告SDK错误类
 */
@interface SeegError : NSObject

/**
 * 错误信息
 */
@property (nonatomic, copy, readonly) NSString *message;

/**
 * 错误码
 */
@property (nonatomic, assign, readonly) int code;

/**
 * 初始化错误对象
 * @param code 错误码
 * @param message 错误信息
 * @return 错误对象实例
 */
- (instancetype)initWithCode:(int)code withMessage:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
