#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <SeegSDK/ZSInitProviding.h>
#import <SeegSDK/ZSEventProviding.h>

@protocol ZSTrackerProviding<ZSInitProviding, ZSEventProviding>

/// 事件跟踪
+ (void)trackEvent:(NSString *)name withParameters:(NSDictionary *)parameters;

@end
