#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, SeegSdkErrorCode) {
    /// 成功
    SeegSdkErrorCodeSuccess                = 0,
    
    /// 平台不支持
    SeegSdkErrorCodePlatformNotSupport     = -1,
    
    /// SDK不存在
    SeegSdkErrorCodeSDKNotExist            = -2,
    
    /// 用户取消
    SeegSdkErrorCodeUserCancel             = -3,
    
    /// 未知错误
    SeegSdkErrorCodeUnknown                = -4,
    
    /// 平台未知错误
    SeegSdkErrorCodePFUnknown              = -1,
    
    /// 广告未加载
    SeegSdkErrorCodeAdNotLoad              = -101,
    
    /// 广告超时
    SeegSdkErrorCodeAdTimeout              = -104,
    
    /// 登录中
    SeegSdkErrorCodeLoginIng               = -101,
    
    /// SDK连接错误
    SeegSdkErrorCodePaySdkConnect          = -101,
    
    /// 没有查找到该商品
    SeegSdkErrorCodePayNotExistProduct     = -102,
    
    /// 消耗失败
    SeegSdkErrorCodeConsumeFail            = -103,
    
    /// 支付中
    SeegSdkErrorCodePayIng                 = -104,
};


NS_ASSUME_NONNULL_END
