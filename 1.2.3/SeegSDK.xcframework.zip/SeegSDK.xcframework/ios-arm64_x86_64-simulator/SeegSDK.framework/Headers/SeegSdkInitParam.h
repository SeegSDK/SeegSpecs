#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegSdkInitParam : NSObject

@property (nonatomic, assign) bool first;

+ (instancetype _Nullable )fromJsonString:(NSString *_Nonnull)jsonString;

@end

NS_ASSUME_NONNULL_END
