#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <SeegSDK/ZSInitProviding.h>
#import <SeegSDK/SeegAdSlot.h>
#import <SeegSDK/SeegAd.h>

@protocol ZSAdProviding<ZSInitProviding>

/*!
 * 完成无参回调
 */
typedef void (^ZSInitComplete)(void);

// 创建开屏广告
+ (id<SeegSplashAd>)createSplashAd;

// 创建Banner广告
+ (id<SeegBannerAd>)createBannerAd;

// 创建插屏广告
+ (id<SeegInterstitialAd>)createInterstitialAd;

// 创建激励视频广告
+ (id<SeegRewardedVideoAd>)createRewardVideoAd;

// 创建信息流广告
+ (id<SeegCustomAd>)createCustomAd;

@end
