#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegModalData : NSObject

@property (nonatomic, copy, nonnull) NSString *title;
@property (nonatomic, copy, nonnull) NSString *content;
@property (nonatomic, copy, nonnull) NSString *submitText;
@property (nonatomic, copy, nonnull) NSString *cancelText;
@property (nonatomic, assign) bool dismiss;

+ (instancetype _Nullable )fromJsonString:(NSString *_Nonnull)jsonString;

@end

NS_ASSUME_NONNULL_END
