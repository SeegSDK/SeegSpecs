#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegProductDetailData : NSObject

/// 商品价格
@property (nonatomic, assign) double price;
/// 商品币种
@property (nonatomic, copy, nonnull) NSString *currency;
/// 商品ID
@property (nonatomic, copy, nonnull) NSString *productId;

/// 当前对象转为json字符串并进行base64处理
- (NSString *_Nonnull)toBase64JSONString;
/// 当前对象转为Dictionary
- (NSDictionary *_Nonnull)toDictionary;

@end

NS_ASSUME_NONNULL_END
