#import <Foundation/Foundation.h>

//! Project version number for SeegBridge.
FOUNDATION_EXPORT double SeegBridgeVersionNumber;

//! Project version string for SeegBridge.
FOUNDATION_EXPORT const unsigned char SeegBridgeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SeegBridge/PublicHeader.h>
