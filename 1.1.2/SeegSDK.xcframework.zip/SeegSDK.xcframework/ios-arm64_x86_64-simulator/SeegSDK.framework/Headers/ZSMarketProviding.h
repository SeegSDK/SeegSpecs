#import <Foundation/Foundation.h>
#import <SeegSDK/ZSInitProviding.h>
#import <SeegSDK/SeegProductDetailParam.h>
#import <SeegSDK/SeegProductDetailData.h>
#import <SeegSDK/SeegPayData.h>
#import <SeegSDK/SeegOrderData.h>

@protocol ZSMarketProviding<ZSInitProviding>

/// 发起支付
+ (void)pay:(SeegPayData *_Nonnull)info completion:(void (^_Nonnull)(SeegOrderData * _Nonnull info)) completion;
/// 消耗(完成)订单
+ (bool)consumeOrder:(SeegOrderData *_Nonnull)info;
/// 掉单处理
+ (void)queryFailOrder:(void (^_Nonnull)(NSArray<SeegOrderData *> * _Nonnull info)) completion;
/// 恢复购买
+ (void)restoreOrder:(void (^_Nonnull)(NSArray<SeegOrderData *> * _Nullable infoList))completion;

@end
