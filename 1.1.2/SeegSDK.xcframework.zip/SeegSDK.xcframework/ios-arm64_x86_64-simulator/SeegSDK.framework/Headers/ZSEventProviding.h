#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <SeegSDK/SeegLoadCompleteEvent.h>
#import <SeegSDK/SeegRegisterEvent.h>
#import <SeegSDK/SeegLoginEvent.h>
#import <SeegSDK/SeegGuideEvent.h>
#import <SeegSDK/SeegAdEvent.h>
#import <SeegSDK/SeegAdRevenue.h>
#import <SeegSDK/SeegLevelEvent.h>
#import <SeegSDK/SeegPurchaseEvent.h>

@protocol ZSEventProviding

+ (void)trackLoadComplete:(SeegLoadCompleteEvent *) param;
+ (void)trackRegister:(SeegRegisterEvent *) param;
+ (void)trackLogin:(SeegLoginEvent *) param;
+ (void)trackGuideStart:(SeegGuideEvent *) param;
+ (void)trackGuideEnd:(SeegGuideEvent *) param;
+ (void)trackAdStart:(SeegAdEvent *) param;
+ (void)trackAdLoad:(SeegAdEvent *) param;
+ (void)trackAdLoadFail:(SeegAdEvent *) param;
+ (void)trackAdShow:(SeegAdEvent *) param;
+ (void)trackAdShowFail:(SeegAdEvent *) param;
+ (void)trackAdCancel:(SeegAdEvent *) param;
+ (void)trackAdEnd:(SeegAdEvent *) param;
+ (void)trackAdRevenue:(SeegAdRevenue *)revenue;
+ (void)trackLevelStart:(SeegLevelEvent *) param;
+ (void)trackLevelLose:(SeegLevelEvent *) param;
+ (void)trackLevelPass:(SeegLevelEvent *) param;
+ (void)trackLevelPropUse:(SeegLevelEvent *) param;
+ (void)trackLevelOperate:(SeegLevelEvent *) param;
+ (void)trackLevelProgress:(SeegLevelEvent *) param;
+ (void)trackLevelReplay:(SeegLevelEvent *) param;
+ (void)trackLevelQuit:(SeegLevelEvent *) param;
+ (void)trackLevelRevive:(SeegLevelEvent *) param;
+ (void)trackPurchasePull:(SeegPurchaseEvent *) param;
+ (void)trackPurchaseFail:(SeegPurchaseEvent *) param;
+ (void)trackPurchaseEnd:(SeegPurchaseEvent *) param;
+ (void)trackPurchaseDelivery:(SeegPurchaseEvent *) param;

@end
