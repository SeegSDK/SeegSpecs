#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 日志输出
@interface SeegLog : NSObject

/// 打印日志
+ (void)log:(NSString *)format, ...;
/// 打印错误信息
+ (void)logError:(NSString *)format, ...;

@end

NS_ASSUME_NONNULL_END
