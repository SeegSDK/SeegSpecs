#import <SeegSDK/SeegAd.h>
#import <SeegSDK/SeegAdSlot.h>

NS_ASSUME_NONNULL_BEGIN

@protocol ZSAdProtocol <NSObject>

- (void)onLoadSuccess;
- (void)onLoadFailed:(int)errCode withPlatformCode:(int) platformCode withPlatformMsg:(NSString *) platformMsg;
- (void)onShowSuccess;
- (void)onShowFailed:(int)errCode withPlatformCode:(int) platformCode withPlatformMsg:(NSString *) platformMsg;
- (void)onReward;
- (void)onClick;
- (void)onClose;
- (void)onCheckSize;
- (void)onAdRevenuePaid:(double) revenue;

@end

@interface ZSAd: NSObject

@property (nonatomic, strong) SeegAdSlot *adSlot;
@property (nonatomic, strong) id<ZSAdProtocol> delegate;

- (instancetype) innerInit:(SeegAdSlot *) adSlot;
- (void) initAd;
- (void) loadAd;
- (void) showAd;
- (void) destroyAd;
- (double)getRevenue;
- (NSString *)getCurrency;
- (NSString *)getNetwork;

-(void) hideAd;
-(void) setStyle:(int)top :(int)left;
@end

NS_ASSUME_NONNULL_END
