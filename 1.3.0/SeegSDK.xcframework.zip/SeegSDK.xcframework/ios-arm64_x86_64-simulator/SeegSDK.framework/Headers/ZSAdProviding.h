#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <SeegSDK/ZSInitProviding.h>
#import <SeegSDK/SeegAdSlot.h>
#import <SeegSDK/SeegAd.h>
#import <SeegSDK/ZSAd.h>

@protocol ZSAdProviding<ZSInitProviding>

/*!
 * 完成无参回调
 */
typedef void (^ZSInitComplete)(void);

// 创建开屏广告
+ (ZSAd *)createSplashAd;

// 创建Banner广告
+ (ZSAd *)createBannerAd;

// 创建插屏广告
+ (ZSAd *)createInterstitialAd;

// 创建激励视频广告
+ (ZSAd *)createRewardVideoAd;

// 创建信息流广告
+ (ZSAd *)createCustomAd;

@end
