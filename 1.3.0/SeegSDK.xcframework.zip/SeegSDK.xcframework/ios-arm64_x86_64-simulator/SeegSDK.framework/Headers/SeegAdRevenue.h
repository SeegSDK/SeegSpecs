#import <Foundation/Foundation.h>

/// SDK广告收益信息
@interface SeegAdRevenue : NSObject

@property (nonatomic, copy, nonnull) NSString *source;

@property (nonatomic, assign) double revenue;

@property (nonatomic, copy, nonnull) NSString *currency;

@property (nonatomic, copy, nonnull) NSString *network;

@property (nonatomic, copy, nonnull) NSString *adUnitId;

@property (nonatomic, copy, nonnull) NSString *placement;

@property (nonatomic, assign) double revenueSum;

+ (instancetype _Nullable )fromJsonString:(NSString *_Nonnull)jsonString;

//-(instancetype _Nonnull)insSetSource: (NSString *_Nonnull)source;
//-(instancetype _Nonnull)insSetRevenue: (double)revenue;
//-(instancetype _Nonnull)insSetCurrency: (NSString *_Nonnull)currency;
//-(instancetype _Nonnull)insSetNetwork: (NSString *_Nonnull)network;
//-(instancetype _Nonnull)insSetAdUnitId: (NSString *_Nonnull)adUnitId;
//-(instancetype _Nonnull)insSetPlacement: (NSString *_Nonnull)placement;

@end

