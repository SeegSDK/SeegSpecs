#import <Foundation/Foundation.h>

//! Project version number for SeegSDK.
FOUNDATION_EXPORT double SeegSDKVersionNumber;

//! Project version string for SeegSDK.
FOUNDATION_EXPORT const unsigned char SeegSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SeegSDK/PublicHeader.h>

// 日志输出
#import <SeegSDK/SeegLog.h>

// 协议
#import <SeegSDK/ZSAdProviding.h>
#import <SeegSDK/ZSAnalyticsProviding.h>
#import <SeegSDK/ZSInitProviding.h>
#import <SeegSDK/ZSMarketProviding.h>
#import <SeegSDK/ZSPFProviding.h>
#import <SeegSDK/ZSTrackerProviding.h>
#import <SeegSDK/ZSEventProviding.h>

#import <SeegSDK/SeegAd.h>

// 主SDK
#import <SeegSDK/SeegSDKManage.h>

