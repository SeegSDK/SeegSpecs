#import <Foundation/Foundation.h>

/// SDK广告收益信息
@interface SeegLoginEvent : NSObject

@property (nonatomic, assign) NSTimeInterval regTime;

@property (nonatomic, assign) int day;
/// 是否本地
@property (nonatomic, assign) BOOL local;

+ (instancetype)fromJsonString:(NSString *)jsonString;

@end

