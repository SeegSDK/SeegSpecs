#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <SeegSDK/ZSInitProviding.h>
#import <SeegSDK/ZSEventProviding.h>

@protocol ZSAnalyticsProviding<ZSInitProviding, ZSEventProviding>

/// 设置公共事件属性
+ (void)setSuperProperties:(NSDictionary *)parameters;
/// 事件上报
+ (void)reportEvent:(NSString *)name withParameters:(NSDictionary *)parameters;
/// 用户数据上报
+ (void)reportUserInfo:(NSString *) setType withParameters:(NSDictionary *)parameters;

@end
