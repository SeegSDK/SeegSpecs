#import <Foundation/Foundation.h>

/// SDK广告收益信息
@interface SeegLoadCompleteEvent : NSObject

@property (nonatomic, assign) int duration;

@property (nonatomic, assign) BOOL first;

/// JSON 字符串转模型
+ (instancetype)fromJsonString:(NSString *)jsonString;

@end

