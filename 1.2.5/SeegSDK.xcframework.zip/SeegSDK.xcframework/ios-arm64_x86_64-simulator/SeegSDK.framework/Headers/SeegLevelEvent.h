#import <Foundation/Foundation.h>

/// SDK广告收益信息
@interface SeegLevelEvent : NSObject

@property (nonatomic, assign) int level;

@property (nonatomic, assign) BOOL revive;

@property (nonatomic, assign) int useTime;

@property (nonatomic, assign) int progress;

@property (nonatomic, copy) NSString* operate;

@property (nonatomic, copy) NSString* prop;

@property (nonatomic, strong) NSDictionary* extra;

+ (instancetype)fromJsonString:(NSString *)jsonString;

@end

