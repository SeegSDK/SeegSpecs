#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegAdSlot : NSObject

@property (nonatomic, copy) NSString *adUnitId;
@property (nonatomic, copy) NSString *userId;
@property (nonatomic, assign) int width;
@property (nonatomic, assign) int height;
@property (nonatomic, assign) int left;
@property (nonatomic, assign) int top;
@property (nonatomic, assign) int adIntervals;

@end

NS_ASSUME_NONNULL_END
