#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegOrderData : NSObject

/// 商品ID
@property (nonatomic, copy, nonnull) NSString *productId;
/// 订单ID
@property (nonatomic, copy, nonnull) NSString *orderId;
/// 支付凭证(票据)
@property (nonatomic, copy, nonnull) NSString *token;
/// 订单价格
@property (nonatomic, assign) double price;
/// 货币类型
@property (nonatomic, copy, nonnull) NSString *currency;
/// 订单状态，1: 购买成功，0: 购买失败，-1: 商品查询失败，2: 恢复订单
@property (nonatomic, assign) int errCode;
/// 订单错误信息
@property (nonatomic, copy, nonnull) NSString *errMsg;

/// 根据json字符串转模型
+ (nullable instancetype)fromJSONString:(NSString *_Nonnull)jsonString;
/// 将对象数组转为Dictionary数组
+ (NSMutableArray *)dictionaryFromArray:(NSArray<SeegOrderData *> *)array;
/// 把数组转为json字符串并进行base64处理
+ (NSString *_Nonnull)base64FromArray:(NSArray<SeegOrderData *> *_Nonnull)array;
/// 当前对象转为json字符串并进行base64处理
- (NSString *_Nonnull)toBase64JSONString;
/// 当前对象转为Dictionary
- (NSDictionary *_Nonnull)toDictionary;

@end

NS_ASSUME_NONNULL_END
