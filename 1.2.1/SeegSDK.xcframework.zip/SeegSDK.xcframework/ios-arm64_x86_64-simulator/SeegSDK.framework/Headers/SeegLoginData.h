#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegLoginData : NSObject

/// 用户ID
@property (nonatomic, copy, nonnull) NSString *userId;

@property (nonatomic, copy, nonnull) NSString *type;

@property (nonatomic, copy, nonnull) NSString *uuid;

/// 当前对象转为json字符串并进行base64处理
- (NSString *_Nonnull)toBase64JSONString;
/// 当前对象转为Dictionary
- (NSDictionary *_Nonnull)toDictionary;

@end

NS_ASSUME_NONNULL_END
