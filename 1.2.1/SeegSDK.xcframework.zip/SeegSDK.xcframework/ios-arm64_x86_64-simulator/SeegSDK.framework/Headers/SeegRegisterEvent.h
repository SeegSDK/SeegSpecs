#import <Foundation/Foundation.h>

/// SDK广告收益信息
@interface SeegRegisterEvent : NSObject

@property (nonatomic, assign) BOOL onlyFirst;

/// JSON 字符串转模型
+ (instancetype)fromJsonString:(NSString *)jsonString;

@end

