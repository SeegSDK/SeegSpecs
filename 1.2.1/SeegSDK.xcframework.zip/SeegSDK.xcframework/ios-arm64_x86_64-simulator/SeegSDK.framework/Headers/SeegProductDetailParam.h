#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegProductDetailParam : NSObject

/// 用户ID
@property (nonatomic, copy, nonnull) NSString *userId;
/// 商品ID
@property (nonatomic, copy, nonnull) NSString *productId;
/// 渠道
@property (nonatomic, copy, nonnull) NSString *channel;

/// 根据json字符串转模型
+ (nullable instancetype)fromJSONString:(NSString *_Nonnull)jsonString;

@end

NS_ASSUME_NONNULL_END
