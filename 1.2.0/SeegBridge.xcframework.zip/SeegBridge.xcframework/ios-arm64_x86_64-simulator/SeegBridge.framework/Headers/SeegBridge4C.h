#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZB4C : NSObject

extern "C" {

void initSdk(const char* param);
const char* getSdkConfig(void);

// 系统功能
void vibrate(int time);
const char* getSystemInfoSync(void);
    const char* getStorageSync(const char* key);
    void setStorageSync(const char* key, const char* data);
    void appReview();
    const char* getAccountInfoSync();
    void gotoStore(const char* appId, const char* url);
    void showModal(const char* data);
    void login(const char* flag, const char* pf);

// 数据分析
void setSuperProperties(const char* param);
void reportEvent(const char* eventName, const char* param);
void reportUserInfo(const char* infoType, const char* param);

// 事件跟踪
void trackEvent(const char* eventName, const char* param);
void trackLoadComplete(const char* params);
void trackRegister(const char* params);
void trackLogin(const char* params);
void trackGuideStart(const char* params);
void trackGuideEnd(const char* params);
void trackSdkInit(const char* params);

    // MARK: 广告事件跟踪
void trackAdStart(const char* params);
void trackAdLoad(const char* params);
void trackAdLoadFail(const char* params);
void trackAdShow(const char* params);
void trackAdShowFail(const char* params);
void trackAdCancel(const char* params);
void trackAdEnd(const char* params);

    // MARK: 关卡事件跟踪
void trackLevelStart(const char* params);
void trackLevelLose(const char* params);
void trackLevelPass(const char* params);
void trackLevelPropUse(const char* params);
void trackLevelOperate(const char* params);
void trackLevelProgress(const char* params);
void trackLevelReplay(const char* params);
void trackLevelQuit(const char* params);
void trackLevelRevive(const char* params); 

    // MARK: 支付事件跟踪
    void trackPurchasePull(const char* params);
    void trackPurchaseFail(const char* params);
    void trackPurchaseEnd(const char* params);
    void trackPurchaseDelivery(const char* params);

// 广告管理
const char* createAd(const char* data);
void loadAd(const char* uuid);
void showAd(const char* uuid);
void hideAd(const char* uuid);
void setAdStyle(const char* uuid, int top, int left);
const char* getAdInfo(const char* uuid);
void destroyAd(const char* uuid);
    
    // MARK: 支付
    void pay(const char* params);
    const char* consumeOrder(const char* params);
    void restoreOrder();
    void queryFailOrder();
}

@end

NS_ASSUME_NONNULL_END
