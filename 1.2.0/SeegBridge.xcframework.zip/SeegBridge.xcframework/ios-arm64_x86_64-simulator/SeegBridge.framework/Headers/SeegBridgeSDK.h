#import <Foundation/Foundation.h>
#import <SeegSDK/SeegSDK.h>
#import <SeegSDK/SeegAd.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegBridgeSDK : NSObject

/// 初始化SDK
+ (void)initSdk:(NSString *)param;
/// 同意协议
+ (void)showPrivacyPolicyDialog:(NSString *)agreementUrl :(NSString *)privacyUrl;
+ (NSString *)getSdkConfig;
/// 获取渠道
+ (NSString *)getChannel;

// MARK: 数据分析
/// 设置公共事件属性
+ (void)setSuperProperties:(NSString *)parameters;
/// 事件上报
+ (void)reportEvent:(NSString *)eventId :(NSString *)parameters;
/// 用户数据上报
+ (void)reportUserInfo:(NSString *)infoType :(NSString *)params;

// MARK: 投放系统
// 事件跟踪
+ (void)trackEvent:(NSString *)name :(NSString *)parameters;
/// 注册事件
+ (void)trackRegister:(NSString *)params;
/// 登录事件
+ (void)trackLogin:(NSString *)params;
/// 加载完成事件
+ (void)trackLoadComplete:(NSString *)params;
/// 引导开始事件
+ (void)trackGuideStart:(NSString *)params;
/// 引导结束事件
+ (void)trackGuideEnd:(NSString *)params;
/// 广告进入事件
+ (void)trackAdStart:(NSString *)params;
/// 广告加载事件
+ (void)trackAdLoad:(NSString *)params;
/// 广告加载失败事件
+ (void)trackAdLoadFail:(NSString *)params;
/// 广告展示事件
+ (void)trackAdShow:(NSString *)params;
/// 广告展示失败事件
+ (void)trackAdShowFail:(NSString *)params;
// 广告取消事件
+ (void)trackAdCancel:(NSString *)params;
// 广告结束事件
+ (void)trackAdEnd:(NSString *)params;
// 关卡事件跟踪
+ (void)trackLevelStart:(NSString *)params;
+ (void)trackLevelLose:(NSString *)params;
+ (void)trackLevelPass:(NSString *)params;
+ (void)trackLevelPropUse:(NSString *)params;
+ (void)trackLevelOperate:(NSString *)params;
+ (void)trackLevelProgress:(NSString *)params;
+ (void)trackLevelReplay:(NSString *)params;
+ (void)trackLevelQuit:(NSString *)params;
+ (void)trackLevelRevive:(NSString *)params;
/// 拉起支付事件
+ (void)trackPurchasePull:(NSString *) param;
/// 支付失败事件
+ (void)trackPurchaseFail:(NSString *) param;
/// 支付成功事件
+ (void)trackPurchaseEnd:(NSString *) param;
/// 发货事件/消耗订单事件
+ (void)trackPurchaseDelivery:(NSString *) param;
+ (void)trackSdkInit:(NSString *) param;

// MARK: 广告
+ (NSString *)createAd:(NSString *)data;
+ (void)loadAd:(NSString *)uuid;
+ (void)showAd:(NSString *)uuid;
+ (void)hideAd:(NSString *)uuid;
+ (void)destroyAd:(NSString *)uuid;
+ (NSString *)getAdInfo:(NSString *)uuid;
+ (void)setAdStyle:(NSString *)uuid :(int)top :(int)left;

// MARK: 系统
/// 系统震动
+ (void)vibrate:(int) time;
/// 获取系统信息
+ (NSString *)getSystemInfoSync;
/// 设置屏幕常亮
+ (void)setKeepScreenOn;
/// 设置剪贴板数据
+ (void)setClipboardData:(NSString *)text;
/// 获取剪贴板数据
+ (NSString *)getClipboardData;
/// 获取远程值
+ (NSString *)getString:(NSString *) key;
/// 弹出Toast
+ (void)showToast:(NSString *)msg :(double)duration;
/// 登录
+ (void)login:(NSString *)flag :(NSString *)pf;
/// 获取本地存储数据
+ (NSString *)getStorageSync:(NSString *)key;
/// 设置本地存储数据
+ (void)setStorageSync:(NSString *)key :(NSString *)data;
/// 应用内评分
+ (void)appReview;
/// 获取账户信息
+ (NSString *)getAccountInfoSync;
/// 跳转到应用商店
+ (void)gotoStore:(NSString *)appId :(NSString *)url;
/// 显示弹框
+ (void)showModal:(NSString *)data;

// MARK: 注册通信回调方法
/// 注册JS通信回调
+ (void)registerJSExecutor:(void (^)(NSString *jsCode))execFunc;
/// 执行JS通信回调
+ (void)runJSCode: (NSString *) jsCode;
/// 注册CS通信回调
+ (void)registerCSExecutor:(void (^)(NSString* gameObject, NSString* funcName, NSString* params))execFunc;
/// 执行CS通信回调
+ (void)runCSCode: (NSString *) gameObject withFunc: (NSString *)funcName withParams:(id) params;

// MARK: 支付
/// 发起支付
+ (void)pay:(NSString *)data;
/// 消耗(完成)订单
+ (bool)consumeOrder:(NSString *)data;
/// 恢复购买
+ (void)restoreOrder;
/// 查询掉单订单
+ (void)queryFailOrder;

@end

NS_ASSUME_NONNULL_END
