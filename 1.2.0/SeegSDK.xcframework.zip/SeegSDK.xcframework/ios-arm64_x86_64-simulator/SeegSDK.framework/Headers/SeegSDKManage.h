#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <SeegSDK/SeegConfig.h>

#import <SeegSDK/SeegSystemInfo.h>
#import <SeegSDK/SeegAccountInfo.h>

#import <SeegSDK/SeegAd.h>
#import <SeegSDK/SeegAdSlot.h>

#import <SeegSDK/SeegLoadCompleteEvent.h>
#import <SeegSDK/SeegRegisterEvent.h>
#import <SeegSDK/SeegLoginEvent.h>
#import <SeegSDK/SeegGuideEvent.h>
#import <SeegSDK/SeegAdEvent.h>
#import <SeegSDK/SeegAdRevenue.h>
#import <SeegSDK/SeegLevelEvent.h>
#import <SeegSDK/SeegPurchaseEvent.h>
#import <SeegSDK/SeegSdkInitParam.h>

#import <SeegSDK/SeegShareInfo.h>
#import <SeegSDK/SeegPayData.h>
#import <SeegSDK/SeegOrderData.h>
#import <SeegSDK/SeegLoginData.h>
#import <SeegSDK/SeegSdkErrorCode.h>
#import <SeegSDK/SeegModalData.h>

NS_ASSUME_NONNULL_BEGIN

@interface SeegSDKManage: NSObject

/// 初始化SDK
+ (void)initSdk: (UIApplication *)application withConfig: (SeegConfig *)config;
+ (NSString *)getSdkConfig;
/// 获取渠道
+ (NSString *)getChannel;

// MARK: 系统
/// 系统震动
+ (void)vibrate:(UIImpactFeedbackStyle) type;
/// 获取系统信息
+ (SeegSystemInfo *)getSystemInfoSync;
/// 设置屏幕常亮
+ (void)setKeepScreenOn;
/// 设置剪贴板数据
+ (void)setClipboardData:(NSString *)text;
/// 获取剪贴板数据
+ (NSString *)getClipboardData;
/// 获取远程值
+ (NSString *)getString:(NSString *) key;
/// 弹出Toast
+ (void)showToast:(NSString *)msg :(double)duration;
/// 登录
+ (void)login:(NSString *)pf success:(void(^)(SeegLoginData *data))success failure:(void(^)(NSInteger errCode, NSInteger pfErr, NSString *message))failure;
/// 获取本地存储数据
+ (NSString *)getStorageSync:(NSString *)key;
/// 设置本地存储数据
+ (void)setStorageSync:(NSString *)key :(NSString *)data;
/// 应用内评分
+ (void)appReview;
/// 请求IDFA
+ (void)requestIDFA;
/// 获取账户信息
+ (SeegAccountInfo *)getAccountInfoSync;
/// 跳转到应用商店
+ (void)gotoStoreWithAppId:(NSString * )appId url:(NSString *)url onResult:(void (^)(BOOL result))onResult;
/// 显示弹框
+ (void)showModal:(SeegModalData *)data :(void(^)(int result))onResult;

// MARK: 广告
// 创建开屏广告
+ (id<SeegSplashAd>)createSplashAd:(SeegAdSlot *)slot delegate:(id<SeegBaseAdProtocol>)delegate;
// 创建Banner广告
+ (id<SeegBannerAd>)createBannerAd:(SeegAdSlot *)slot delegate:(id<SeegBaseAdProtocol>)delegate;
// 创建插屏广告
+ (id<SeegInterstitialAd>)createInterstitialAd:(SeegAdSlot *)slot delegate:(id<SeegBaseAdProtocol>)delegate;
// 创建激励视频广告
+ (id<SeegRewardedVideoAd>)createRewardVideoAd:(SeegAdSlot *)slot delegate:(id<SeegBaseAdProtocol>)delegate;
// 创建信息流广告
+ (id<SeegCustomAd>)createCustomAd:(SeegAdSlot *)slot delegate:(id<SeegBaseAdProtocol>)delegate;

// MARK: 数据分析
/// 设置公共事件属性
+ (void)setSuperProperties:(NSDictionary *)parameters;
/// 事件上报
+ (void)reportEvent:(NSString *)name withParameters:(NSDictionary *)parameters;
/// 用户数据上报
+ (void)reportUserInfo:(NSString *) setType withParam:(nonnull NSDictionary *)parameters;
/// 事件跟踪
+ (void)trackEvent:(NSString *)name withParameters:(NSDictionary *)parameters;

// MARK: 通用打点事件
+ (void)trackLoadComplete:(SeegLoadCompleteEvent *) param;
+ (void)trackRegister:(SeegRegisterEvent *) param;
+ (void)trackLogin:(SeegLoginEvent *) param;
+ (void)trackGuideStart:(SeegGuideEvent *) param;
+ (void)trackGuideEnd:(SeegGuideEvent *) param;
+ (void)trackAdStart:(SeegAdEvent *) param;
+ (void)trackAdLoad:(SeegAdEvent *) param;
+ (void)trackAdLoadFail:(SeegAdEvent *) param;
+ (void)trackAdShow:(SeegAdEvent *) param;
+ (void)trackAdShowFail:(SeegAdEvent *) param;
+ (void)trackAdCancel:(SeegAdEvent *) param;
+ (void)trackAdEnd:(SeegAdEvent *) param;
+ (void)trackAdRevenue:(SeegAdRevenue *)revenue;
+ (void)trackLevelStart:(SeegLevelEvent *) param;
+ (void)trackLevelLose:(SeegLevelEvent *) param;
+ (void)trackLevelPass:(SeegLevelEvent *) param;
+ (void)trackLevelPropUse:(SeegLevelEvent *) param;
+ (void)trackLevelOperate:(SeegLevelEvent *) param;
+ (void)trackLevelProgress:(SeegLevelEvent *) param;
+ (void)trackLevelReplay:(SeegLevelEvent *) param;
+ (void)trackLevelQuit:(SeegLevelEvent *) param;
+ (void)trackLevelRevive:(SeegLevelEvent *) param;
+ (void)trackPurchasePull:(SeegPurchaseEvent *) param;
+ (void)trackPurchaseFail:(SeegPurchaseEvent *) param;
+ (void)trackPurchaseEnd:(SeegPurchaseEvent *) param;
+ (void)trackPurchaseDelivery:(SeegPurchaseEvent *) param;
+ (void)trackSdkInit:(SeegSdkInitParam *) param;

// MARK: 分享
/// 分享
+ (void)share:(NSString *)type withData:(SeegShareInfo *)data;
/// 分享后跳转回APP回调
+ (BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options;

// MARK: 支付
/// 发起支付
+ (void)pay:(SeegPayData *)data completion:(void (^ _Nonnull)(SeegOrderData * _Nonnull info))completion;
/// 消耗(完成)订单
+ (bool)consumeOrder:(SeegOrderData *)data;
/// 查询掉单订单
+ (void)queryFailOrder:(void (^_Nonnull)(NSArray<SeegOrderData *> * _Nonnull infoList)) completion;
/// 恢复购买
+ (void)restoreOrder:(void (^_Nonnull)(NSArray<SeegOrderData *> * _Nullable infoList))completion;

@end

NS_ASSUME_NONNULL_END
