#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// SDK支付信息
@interface SeegPayData : NSObject

/// 商品ID
@property (nonatomic, copy, nonnull) NSString *productId;
/// 用户ID
@property (nonatomic, copy, nonnull) NSString *userId;

/// 根据json字符串转模型
+ (nullable instancetype)fromJSONString:(NSString *_Nonnull)jsonString;

@end

NS_ASSUME_NONNULL_END
