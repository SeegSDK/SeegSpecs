#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 账户信息模型
@interface SeegAccountInfo : NSObject

/// app包id
@property (nonatomic, copy, nonnull) NSString *appId;
/// app版本
@property (nonatomic, copy, nonnull) NSString *version;
/// app模式 debug/release
@property (nonatomic, copy, nonnull) NSString *envVersion;

/// 转为 JSON 字符串
- (nullable NSString *)toJSONString;

@end

NS_ASSUME_NONNULL_END
