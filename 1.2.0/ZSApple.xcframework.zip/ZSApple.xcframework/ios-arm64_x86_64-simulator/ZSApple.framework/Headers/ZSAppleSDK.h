#import <Foundation/Foundation.h>
#import <SeegSDK/ZSMarketProviding.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZSAppleSDK : NSObject<ZSMarketProviding>

@end

NS_ASSUME_NONNULL_END
