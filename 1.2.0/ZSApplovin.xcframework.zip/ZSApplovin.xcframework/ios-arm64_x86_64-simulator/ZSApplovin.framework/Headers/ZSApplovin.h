#import <Foundation/Foundation.h>

//! Project version number for ZSApplovin.
FOUNDATION_EXPORT double ZSApplovinVersionNumber;

//! Project version string for ZSApplovin.
FOUNDATION_EXPORT const unsigned char ZSApplovinVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZSApplovin/PublicHeader.h>
