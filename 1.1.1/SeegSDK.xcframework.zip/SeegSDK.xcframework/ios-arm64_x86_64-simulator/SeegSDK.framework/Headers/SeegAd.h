
#import <Foundation/Foundation.h>
#import <SeegSDK/SeegError.h>



@protocol SeegBaseAdProtocol <NSObject>

- (void)onLoadSuccess: (_Nonnull id) ad;
- (void)onLoadFailed: (_Nonnull id) ad withError:(nullable SeegError *)error;
- (void)onShowSuccess: (_Nonnull id) ad;
- (void)onShowFailed: (_Nonnull id) ad withError:(nullable SeegError *)error;
- (void)onClick: (_Nonnull id) ad;
- (void)onAdRevenuePaid: (_Nonnull id) ad withRevenue: (double) revenue;


@end

@protocol SeegBaseViewAdProtocol <SeegBaseAdProtocol>

- (void)onResize: (_Nonnull id) ad withSize:(CGSize)size;

@end

@protocol SeegBaseVideoAdProtocl <SeegBaseAdProtocol>

- (void)onClose: (_Nonnull id) ad withRewarded:(BOOL)reward;

@end

@protocol SeegSplashAdProtocol <SeegBaseAdProtocol>


@end

@protocol SeegBannerAdProtocol <SeegBaseViewAdProtocol>


@end

@protocol SeegInterstitialAdProtocol <SeegBaseVideoAdProtocl>

@end

@protocol SeegRewardedVideoAdProtocol <SeegBaseVideoAdProtocl>

@end

@protocol SeegCustomAdProtocol <SeegBaseViewAdProtocol>


@end



@protocol SeegBaseAd <NSObject>

- (void)loadAd;
- (void)showAd;
- (void)destroyAd;
- (nonnull NSString *)getAdUnitId;
- (nonnull NSString *)getSource;
- (nonnull NSString *)getNetwork;
- (double)getRevenue;
- (nonnull NSString *)getCurrency;
- (nonnull NSString *)getPlacement;

@end


@protocol SeegBaseViewAd <SeegBaseAd>

- (void)hideAd;
- (void)setStyleTop:(NSInteger) top withLeft:(NSInteger) left;

@end

@protocol SeegBaseVideoAd <SeegBaseAd>

@end

@protocol SeegSplashAd <SeegBaseAd>

@property (nonatomic, strong) id<SeegSplashAdProtocol> _Nullable delegate;

@end

@protocol SeegBannerAd <SeegBaseViewAd>

@property (nonatomic, strong) id<SeegBannerAdProtocol> _Nullable delegate;

@end

@protocol SeegInterstitialAd <SeegBaseAd>

@property (nonatomic, strong) id<SeegInterstitialAdProtocol> _Nullable delegate;

@end

@protocol SeegRewardedVideoAd <SeegBaseAd>

@property (nonatomic, strong) id<SeegRewardedVideoAdProtocol> _Nullable delegate;

@end

@protocol SeegCustomAd <SeegBaseViewAd>

@property (nonatomic, strong) id<SeegCustomAdProtocol> _Nullable delegate;

@end





