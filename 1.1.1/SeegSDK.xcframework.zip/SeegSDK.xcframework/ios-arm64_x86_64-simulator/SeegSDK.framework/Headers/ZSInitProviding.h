#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol ZSInitProviding

@property (nonatomic, copy) NSString *sdkName;

// 初始化
+ (void)init:(UIApplication *)application withParameters: (NSDictionary *)options debug: (BOOL)debug;

@end
