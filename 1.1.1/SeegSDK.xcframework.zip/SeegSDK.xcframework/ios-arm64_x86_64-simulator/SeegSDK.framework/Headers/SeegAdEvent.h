#import <Foundation/Foundation.h>

/// SDK广告收益信息
@interface SeegAdEvent : NSObject

@property (nonatomic, copy, nonnull) NSString *placement;

@property (nonatomic, copy, nonnull) NSString *positionTag;

@property (nonatomic, assign) double revenue;

@property (nonatomic, assign) NSInteger errCode;

@property (nonatomic, copy, nonnull) NSString *errMsg;

@property (nonatomic, assign) int positionSum;

@property (nonatomic, assign) int placementSum;

@property (nonatomic, strong) NSDictionary* extra;

+ (instancetype _Nullable )fromJsonString:(NSString *_Nonnull)jsonString;

@end

