#import <Foundation/Foundation.h>

//! Project version number for ZSApple.
FOUNDATION_EXPORT double ZSAppleVersionNumber;

//! Project version string for ZSApple.
FOUNDATION_EXPORT const unsigned char ZSAppleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZSApple/PublicHeader.h>
