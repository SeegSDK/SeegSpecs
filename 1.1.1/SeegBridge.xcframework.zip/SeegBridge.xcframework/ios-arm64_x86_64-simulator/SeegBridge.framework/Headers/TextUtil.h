#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TextUtil : NSObject

+ (NSString *)data2json:(id)object;

@end

NS_ASSUME_NONNULL_END
